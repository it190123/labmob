package com.example.lab4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
